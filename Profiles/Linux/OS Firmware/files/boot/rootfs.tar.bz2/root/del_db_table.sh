#!/bin/sh
SHELL=/bin/sh
PATH=/bin:/sbin:/usr/bin:/usr/sbin


# 重定向整个脚本的输出到日志文件，包括错误信息，这个是将所有的输出重定向，包括终端的输出
# exec > /root/del_db_table.log 2>&1	# 覆盖
# exec >> /root/del_db_table.log 2>&1		# 追加

info() {
	echo "$1" >> /root/del_db_table.log 2>&1
}

# 定义数据库文件夹路径
DB_FOLDER="/mnt/sdcard/part1"

# 定义数据库路径
DB_PATH_PCS="$DB_FOLDER/PCS.db"
DB_PATH_BATTERY="$DB_FOLDER/battery.db"
DB_PATH_SENSOR="$DB_FOLDER/sensor.db"

# 为每个数据库执行检查和清理操作
check_and_clean_db() {
    db_path="$1"
    max_days="$2"
    num_slave="$3"

    max_tables=$((max_days * num_slave))

    # 检查数据库文件是否存在（文件夹不存在同样报错）
    if [ ! -f "$db_path" ]; then
        info "数据库文件不存在: $db_path"
        return 1  # 返回一个非零值表示错误
    fi

	# 输入密钥\获取所有表的名称，如果数据库不存在，此命令会自动创建
	# 执行sqlcipher命令时输出：Error: file is not a database，是因为没有输入正确的密钥
	tables=$(sqlcipher "$db_path" "PRAGMA key = '$DB_KEY1'; SELECT name FROM sqlite_master WHERE type='table';" 2>> /root/del_db_table.log | grep -v 'ok' | grep -E '^[^ ]+$')
	# 1 : Error: disk I/O error
	rc=$?
	info "获取个数,结果:$rc"
	if [ $rc -ne 0 ]; then
        # 打开数据库失败或者没有表，都会走进这里
		available_space=$(df "/mnt/sdcard/part1" | awk 'NR==2 {print $4}') # 获取可用空间
		return 2
	fi
	# info "tables:$tables"
	
	# info "key:$DB_KEY"

    # 如果没有表，则直接返回
    if [ -z "$tables" ]; then
        info "数据库 $db_path 中没有表。"
        return 3
    fi

    # 统计表的数量
    count=$(echo "$tables" | wc -l | tr -d ' ')
	info "数据库 $db_path 中的表个数：$count"

    # 如果表的个数超过限制，则删除最旧的表
    if [ "$count" -gt "$max_tables" ]; then
	
		sql_commands="PRAGMA key = '$DB_KEY';"
			
        # 根据table名称格式：addr_date，找到最早的date。由于sqlite没有保存表创建日期，因此用这种方法。
        earliest_date=$(echo "$tables" | sed -n 's/.*_\([0-9]\+\)$/\1/p' | sort | head -n 1)

		del_table="删除数据表："		# 赋值语句=前后不能有空格
        # 删除所有带有最早日期的表
        for table in $tables; do
            if echo "$table" | grep -q "_$earliest_date$"; then
				# 执行此删除操作时，每删除一个table大约需要4s——是因为输入密钥-验证密钥，如果数据库没有密钥则删除table不足1s
                # sqlcipher "$db_path" "PRAGMA key = '$DB_KEY'; DROP TABLE \"$table\";"
				sql_commands="${sql_commands} DROP TABLE \"$table\";"
				del_table="${del_table},$table"
            fi
        done
		
        # 执行所有 SQL 命令,需要4s
        echo "$sql_commands" | sqlcipher "$db_path" 2>> /root/del_db_table.log
		rc=$?
		info "删除，结果:$rc"
		if [ $rc -eq 0 ]; then
			info "已从数据库 $db_path,$del_table"
		else
			info "从数据库 $db_path,$del_table，失败"
		fi
    fi
}

# 打印当前时间
info -e
info "del_db_table: $(date +"%Y-%m-%d %H:%M:%S")"
# 为每个数据库路径调用函数
check_and_clean_db "$DB_PATH_BATTERY" 1 14
# check_and_clean_db "$DB_PATH_PCS" 90 1
check_and_clean_db "$DB_PATH_SENSOR" 90 1
