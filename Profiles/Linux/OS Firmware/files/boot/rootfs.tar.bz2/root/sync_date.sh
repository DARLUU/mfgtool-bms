#!/bin/sh

# Check if ntpd is already running and terminate it
if ps aux | grep -v grep | grep "/usr/sbin/ntpd" > /dev/null; then
    echo "Stopping existing ntpd process..."
    killall ntpd
    sleep 2  # Wait for process to terminate
fi

# Start a new ntpd process
echo "Starting ntpd..."
/usr/sbin/ntpd -g -q -c /etc/ntp.conf

# Check the exit status of ntpd to determine if synchronization was successful
if [ $? -eq 0 ]; then
    logger -p local0.info "NTP synchronization successful. Updating hardware clock..."
    hwclock -w  # Update hardware clock
    date -u +"%Y%m%d%H%M%S" 2>/dev/null > /etc/timestamp
else
    logger -p local0.info "NTP synchronization failed."
fi

