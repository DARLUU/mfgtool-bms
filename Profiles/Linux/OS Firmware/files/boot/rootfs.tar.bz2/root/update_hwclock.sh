#!/bin/sh
SHELL=/bin/sh
PATH=/bin:/sbin:/usr/bin:/usr/sbin

ntp_status=$(ntpq -c rv)

#echo ${ntp_status} >> /root/update_hwclock.log

if [[ "$ntp_status" == *"stratum"* ]]; then
  hwclock --systohc --utc
  echo "Hardware clock updated." >> /root/update_hwclock.log
else
  echo "NTP not synced. Hardware clock not updated." >> /root/update_hwclock.log
fi

