#!/bin/sh

# 设定SD卡和U盘的设备名称及挂载点
USB_DRIVE="/dev/$MDEV"
MOUNT_POINT_USB="/mnt/usb"
SD_CARD_DEVICE="/dev/mmcblk0"
MOUNT_POINT_SDCARD_PART1="/mnt/sdcard/part1"
MOUNT_POINT_SDCARD_PART2="/mnt/sdcard/part2"

error() {
    echo "error：$1" | tee -a /var/log/hotplug_usb.log >&2
}

warning() {
    echo "warning: $1" | tee -a /var/log/hotplug_usb.log >&1
}

info() {
    # echo "info: $1" | tee -a /var/log/hotplug_usb.log
    echo "$1" | tee -a /var/log/hotplug_usb.log
}


# 复制文件的函数，包括文件夹
copy_files() {
        # 根据ctime排序，先复制新文件
        # for file in $(ls -t $1); do
        # done

        # 复制所有文件
        info "copy_files"
        # 使用 rsync 命令从SD卡复制文件到U盘。-a 选项表示归档模式，它保留了文件的属性；-v 表示详细模式，--progress 显示复制进度。
        # 文件复制过程中如果U盘空间不足，rsync 会停止复制并返回一个错误，但它不会损坏已经复制的文件。直接用cp -a会在U盘空间不足时损坏文件
        # 在 rsync 命令中使用 --partial 选项，这样即使复制中断，部分复制的文件也会被保留，而不是被删除。
        # rsync -av --progress --partial $1/* $2

    cp -a $1/* $2
    if [ $? -ne 0 ]; then
        error "错误：U盘空间不足，终止复制"
        return 1
    fi

        return 0
}

# 压缩并复制文件的函数
compress_and_copy() {
	info "compress_and_copy"
	tar -cf $2 -C $1 .
    if [ $? -ne 0 ]; then
        error "错误：U盘空间不足或其他原因，终止复制"
        return 1
    fi
        return 0
}

# 压缩并复制文件的函数,弃用
compress_and_copy_Deprecated() {
        # 文件太大时，压缩到临时文件会导致内存不够
        # 考虑到数据的完整性和安全性，使用先压缩再复制的方法
    # 创建一个临时文件用于存储压缩文件
    TEMP_FILE=$(mktemp /tmp/sdcard_backup.XXXXXX)

    # 压缩SD卡分区内容
    tar -cf $TEMP_FILE -C $1 .

    # 复制到U盘
    cp $TEMP_FILE $2
    if [ $? -ne 0 ]; then
        error "错误：U盘空间不足，终止复制"
        rm $TEMP_FILE
        return 1
    fi

    # 删除临时文件
    rm $TEMP_FILE
        return 0
}

# 挂载U盘
mount_usb() {
	# 检查文件系统类型
	# 获取/dev/sda1的分区类型ID
	PART_TYPE_ID=$(fdisk -l | grep "^$USB_DRIVE" | awk '{print $8}')

	# 判断分区类型ID并输出相应信息
	if [ "$PART_TYPE_ID" = "c" ]; then
		info "文件类型为Win95 FAT32(LBA)($PART_TYPE_ID)，尝试挂载"
		mkdir -p $MOUNT_POINT_USB
		mount $USB_DRIVE $MOUNT_POINT_USB
		if [ $? -ne 0 ]; then
			error "设备$USB_DRIVE 挂载失败"
			return 1
		fi
		info "挂载成功"
	elif [ "$PART_TYPE_ID" = "e" ]; then
		info "文件类型为Win95 FAT16(LBA)($PART_TYPE_ID)，尝试挂载"
		mkdir -p $MOUNT_POINT_USB
		mount $USB_DRIVE $MOUNT_POINT_USB
		if [ $? -ne 0 ]; then
			error "设备$USB_DRIVE 挂载失败"
			return 1
		fi
		info "挂载成功"
	elif [ "$PART_TYPE_ID" = "7" ]; then
		# NTFS和exFAT的id都是7
		mkdir -p $MOUNT_POINT_USB
		ntfs-3g $USB_DRIVE $MOUNT_POINT_USB
		if [ $? -ne 0 ]; then
			mount.exfat $USB_DRIVE $MOUNT_POINT_USB
			if [ $? -ne 0 ]; then
				error "设备$USB_DRIVE,文件类型ID为$PART_TYPE_ID,挂载失败"
				return 1
			else
				info "文件类型为exFAT($PART_TYPE_ID)，尝试挂载"
			fi
		else
			info "文件类型为HPFS/NTFS($PART_TYPE_ID)，尝试挂载"
		fi
		info "挂载成功"
	else
		error "Unknown partition type ID: $PART_TYPE_ID"
		return 1
	fi

	return 0
}

umount_usb() {
	# 获取所有已挂载的设备和分区及其挂载点,循环卸载每个设备和分区
	mount | grep "^$USB_DRIVE" | while read -r line; do
		device=$(echo "$line" | awk '{print $1}')
		mount_point=$(echo "$line" | awk '{print $3}')

		# 检查挂载点是否存在，避免已经拔出的情况
		if [ -d "$mount_point" ]; then
				# umount -l ：延迟卸载，会将文件系统中的挂载点对用户不可见，但是实际会等到没有进程操作设备时再卸载
				info "尝试卸载设备 $device 上的挂载点 $mount_point"
				cp /var/log/hotplug_usb.log $mount_point
				sync
				umount -l "$mount_point"

				# 检查卸载是否成功
				if [ $? -eq 0 ]; then
					info "卸载成功，删除挂载点 $mount_point"
					rmdir "$mount_point"
				else
					info "卸载失败，设备 $device 上的挂载点 $mount_point 仍然存在，强制卸载"
					# 在这里可以添加处理卸载失败的逻辑
					sync
					umount -f "$mount_point"
				fi
		else
			info "挂载点 $mount_point 不存在，可能已经拔出"
		fi
	done

	info "$USB_DRIVE已卸载"
}

# ACTION=add
info "$USB_DRIVE: $ACTION"

# []中间需要空格
if [ "$ACTION" = "remove" ]; then
        umount_usb
elif [ "$ACTION" = "add" ]; then
        # 检查U盘是否存在
        if [ ! -b "$USB_DRIVE" ]; then
			error "USB设备$USB_DRIVE不存在，退出"
			exit 1
        fi

        # 检查SD卡分区是否存在
        if [ ! -d $MOUNT_POINT_SDCARD_PART1 ] && [ ! -d $MOUNT_POINT_SDCARD_PART2 ]; then
			error "SD卡两个分区均没有挂载"
			umount_usb
			exit 1
        fi


        # 挂载U盘
        mount_usb
        if [ $? -ne 0 ]; then
			exit 1
        fi

        # 检查U盘剩余空间 NR==2：仅处理第二行
        USB_FREE_SPACE=$(df $MOUNT_POINT_USB | awk 'NR==2 {print $4}')

        # SD卡使用空间
        SDCARD_PART1_USED_SPACE=$(df $MOUNT_POINT_SDCARD_PART1 | awk 'NR==2 {print $3}')
        SDCARD_PART2_USED_SPACE=$(df $MOUNT_POINT_SDCARD_PART2 | awk 'NR==2 {print $3}')

        # 要求USB空间富裕些，防止过于临界
        USB_MORE_SPACE=5

        USB_NEED_SPACE=$((SDCARD_PART1_USED_SPACE + SDCARD_PART2_USED_SPACE + USB_MORE_SPACE))

        info "$USB_DRIVE剩余空间：$USB_FREE_SPACE KB"
        info "SD卡分区1使用空间：$SDCARD_PART1_USED_SPACE KB"
        info "SD卡分区2使用空间：$SDCARD_PART2_USED_SPACE KB"
        info "$USB_DRIVE需要空间：$USB_NEED_SPACE KB"

        # 将空间转换为GB（假设df的输出是以KB为单位）
        # FREE_SPACE_GB=$(($FREE_SPACE / 1024 / 1024))

        # 如果USB剩余空间小于SDCARD使用空间，则执行copy_files，否则执行compress_and_copy
        if [ $USB_FREE_SPACE -gt $USB_NEED_SPACE ]; then
			# 创建目标文件夹
			# mkdir -p $MOUNT_POINT_USB/RUN_DATA
			# mkdir -p $MOUNT_POINT_USB/REC_DATA

			# 检查文件夹是否存在
			# if [ ! -d "$MOUNT_POINT_USB/RUN_DATA" ] || [ ! -d "$MOUNT_POINT_USB/REC_DATA" ]; then
				# error "在U盘中创建文件夹失败"
				# umount_usb
				# exit 1
			# fi


			# 检查并挂载SD卡分区1
			if [ ! -d $MOUNT_POINT_SDCARD_PART1 ]; then
				error "SD分区1挂载点$MOUNT_POINT_SDCARD_PART1 不存在"
			else
				# copy_files $MOUNT_POINT_SDCARD_PART1 $MOUNT_POINT_USB/RUN_DATA
				compress_and_copy $MOUNT_POINT_SDCARD_PART1 $MOUNT_POINT_USB/RUN_DATA.tar.gz
				if [ $? -ne 0 ]; then
						# 卸载设备
						umount_usb
						exit 1
				fi
			fi

			# 检查并挂载SD卡分区2
			if [ ! -d $MOUNT_POINT_SDCARD_PART2 ]; then
				error "SD分区2挂载点$MOUNT_POINT_SDCARD_PART2 不存在"
			else
				# copy_files $MOUNT_POINT_SDCARD_PART2 $MOUNT_POINT_USB/REC_DATA
				compress_and_copy $MOUNT_POINT_SDCARD_PART2 $MOUNT_POINT_USB/REC_DATA.tar.gz
				if [ $? -ne 0 ]; then
						# 卸载设备
						umount_usb
						exit 1
				fi
			fi
			# 完成复制
			info "复制完成"
        else
			error "U盘空间不足，没有复制"
        fi
        # else
                # if [ ! -d $MOUNT_POINT_SDCARD_PART1 ]; then
                        # error "SD分区1挂载点$MOUNT_POINT_SDCARD_PART1 不存在"
                # else
                        # compress_and_copy $MOUNT_POINT_SDCARD_PART1 $MOUNT_POINT_USB/RUN_DATA.tar.gz
                        # if [ $? -ne 0 ]; then
                                # umount_usb
                                # exit 1
                        # fi
                # fi

                # if [ ! -d $MOUNT_POINT_SDCARD_PART2 ]; then
                        # error "SD分区2挂载点$MOUNT_POINT_SDCARD_PART2 不存在"
                # else
                        # compress_and_copy $MOUNT_POINT_SDCARD_PART2 $MOUNT_POINT_USB/REC_DATA.tar.gz
                        # if [ $? -ne 0 ]; then
                                # umount_usb
                                # exit 1
                        # fi
                # fi
        # fi


        # 卸载设备
        umount_usb
fi
