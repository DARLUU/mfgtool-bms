#!/bin/sh

# $MDEV为设备,mmcblk0
SD_CARD_DEVICE="/dev/$MDEV"
# 单位为扇区sector，1 sector=512B，最少6GB
TOTAL_SIZE_THRESHOLD=12582912
PARTITION_COUNT_EXPECTED=2
FSTYPE_EXPECTED="c" # Win95 FAT32 (LBA) 的类型ID
MOUNT_POINT_BASE="/mnt/sdcard/part"
MAX_WAIT=6  # umount时最大等待时间，单位为秒

error() {
    echo "error：$1" | tee -a /var/log/hotplug_sdcard.log >&2
}

warning() {
    echo "warning: $1" | tee -a /var/log/hotplug_sdcard.log >&1
}

info() {
    # echo "info: $1" | tee -a /var/log/hotplug_sdcard.log
    echo "$1" | tee -a /var/log/hotplug_sdcard.log
}

mount_sdcard() {
	success=0
	# 检查新分区是否成功创建
	PARTITION_COUNT=$(fdisk -l $SD_CARD_DEVICE | grep -c "^${SD_CARD_DEVICE}p[0-9]")
	# 挂载每个分区
	for PARTITION_NUM in $(seq 1 $PARTITION_COUNT); do
		PARTITION="${SD_CARD_DEVICE}p${PARTITION_NUM}"
		MOUNT_POINT="${MOUNT_POINT_BASE}${PARTITION_NUM}"
		mkdir -p $MOUNT_POINT
		# umask设置权限
		mount -t vfat $PARTITION $MOUNT_POINT -o umask=022
		if [ $? -eq 0 ]; then
			info "SD卡 $PARTITION 已成功挂载"
		else
			success=1
			info "SD卡 $PARTITION 挂载失败"
		fi
	done
	return $success
}

umount_sdcard_1() {
	for PARTITION in $(fdisk -l $SD_CARD_DEVICE | grep "^${SD_CARD_DEVICE}p[0-9]" | awk '{print $1}'); do
		# 检查设备是否被占用
		while fuser $PARTITION >/dev/null 2>&1; do
			info "等待设备 $PARTITION 不再被占用..."
			sleep 3
			WAIT_TIME=$((WAIT_TIME + 3))
			# 如果等待时间超过1分钟，则尝试强制卸载
			if [ $WAIT_TIME -ge $MAX_WAIT ]; then
				warning "等待时间超过1分钟，尝试强制卸载 $PARTITION ..."
				umount -f $PARTITION
				break
			fi
		done
		# 如果设备没有被强制卸载，尝试正常卸载
		if [ $WAIT_TIME -lt $MAX_WAIT ]; then
			umount $PARTITION 2> /dev/null
			# 检查卸载是否成功
			if [ $? -ne 0 ]; then
				warning "SD卡分区 $PARTITION 正常卸载失败，尝试强制卸载"
				umount -f $PARTITION
			fi
			# if mount | grep -q $PARTITION; then
				# info "卸载失败"
				# success=1
			# fi
		fi
	done
}

umount_sdcard() {
	# 获取所有已挂载的SD卡设备和分区及其挂载点,循环卸载每个设备和分区
	mount | grep "^$SD_CARD_DEVICE" | while read -r line; do
		device=$(echo "$line" | awk '{print $1}')
		mount_point=$(echo "$line" | awk '{print $3}')
		
		# 检查挂载点是否存在，避免已经拔出的情况
		if [ -d "$mount_point" ]; then
			# umount -l ：延迟卸载，会将文件系统中的挂载点对用户不可见，但是实际会等到没有进程操作设备时再卸载
			info "尝试卸载设备 $device 上的挂载点 $mount_point"
			sync
			umount -l "$mount_point"
			
			# 检查卸载是否成功
			if [ $? -eq 0 ]; then
				info "卸载成功，删除挂载点 $mount_point"
				rmdir "$mount_point"
			else
				info "卸载失败，设备 $device 上的挂载点 $mount_point 仍然存在，强制卸载"
				# 在这里可以添加处理卸载失败的逻辑
				sync
				umount -f "$mount_point"
			fi
		else
			info "挂载点 $mount_point 不存在，可能已经拔出"
		fi
	done

	#info "卸载模块"
	#rmmod g_mass_storage.ko
	info "所有SD卡及其分区已卸载"
}

# 返回：0 成功，1 重新分区，2 设备不存在报错退出，3 sd卡容量不够报错退出
check_sdcard() {
	# 步骤 1: 检查设备是否存在
	if [ ! -b "$SD_CARD_DEVICE" ]; then
		error "SD卡设备未找到: $SD_CARD_DEVICE"
		return 2
	fi

	# 步骤 2: 获取并检查SD卡的总容量
	TOTAL_SIZE=$(fdisk -l $SD_CARD_DEVICE | grep "Disk $SD_CARD_DEVICE" | awk '{print $7}')
	info "SD卡总容量: $TOTAL_SIZE *512 字节"

	if [ "$TOTAL_SIZE" -lt "$TOTAL_SIZE_THRESHOLD" ]; then
		error "SD卡容量小于 $TOTAL_SIZE_THRESHOLD *512 字节"
		return 3
	fi

	# 步骤 3: 获取分区个数
	PARTITION_COUNT=$(fdisk -l $SD_CARD_DEVICE | grep -c "^${SD_CARD_DEVICE}p[0-9]")
	info "SD卡分区个数: $PARTITION_COUNT"

	NEED_PARTITIONING=0
	if [ "$PARTITION_COUNT" -ne "$PARTITION_COUNT_EXPECTED" ]; then
		warning "分区个数 $PARTITION_COUNT 不为 $PARTITION_COUNT_EXPECTED"
		NEED_PARTITIONING=1
	else
		# 步骤 4 和 5: 遍历分区
		PARTITION_SIZE_THRESHOLD=$(($TOTAL_SIZE / 3))
		for PARTITION in $(fdisk -l $SD_CARD_DEVICE | grep "^${SD_CARD_DEVICE}p[0-9]" | awk '{print $1}'); do
			# PARTITION_SIZE=$(fdisk -l $PARTITION | grep "Disk $PARTITION:" | awk '{print $5}')
			PARTITION_INFO=$(fdisk -l $SD_CARD_DEVICE | grep $PARTITION)
			PARTITION_TYPE=$(echo $PARTITION_INFO | awk '{print $8}')
			PARTITION_SIZE=$(echo $PARTITION_INFO | awk '{print $6}')

			info "分区 $PARTITION 大小: $PARTITION_SIZE *512 字节 类型: $PARTITION_TYPE"

			if [ "$PARTITION_SIZE" -lt "$PARTITION_SIZE_THRESHOLD" ]; then
				warning "分区 $PARTITION 大小小于总容量的1/3"
				NEED_PARTITIONING=1
			fi

			if [ "$PARTITION_TYPE" != "$FSTYPE_EXPECTED" ]; then
				warning "分区类型 $PARTITION_TYPE 不为 $FSTYPE_EXPECTED"
				NEED_PARTITIONING=1
			fi
		done
	fi
	
	if [ $NEED_PARTITIONING -ne 0 ]; then
		return 1
	else
		info "SD卡符合要求"
		return 0
	fi
}

partition_and_format_sdcard() {
	WAIT_TIME=0
	success=0
	# 步骤 10: 检查分区个数和分区检查结果
	info "重新分区并格式化 SD 卡..."

	# 卸载所有分区
	umount_sdcard

	# 删除所有现有分区
	info "删除现有分区($PARTITION_COUNT个)..."
	i=1
	while [ $i -le $PARTITION_COUNT ]; do
		echo "d
	$i
	" | fdisk $SD_CARD_DEVICE
		if [ $? -ne 0 ]; then
			error "SD卡分区 $i 删除失败"
			success=2
		fi
		i=$((i + 1))
	done

	# 创建两个新分区
	info "创建新分区..."
	(echo o; echo n; echo p; echo 1; echo; echo +$(($TOTAL_SIZE / 2)); echo t; echo c; echo n; echo p; echo 2; echo; echo; echo t; echo 2; echo c; echo w) | fdisk $SD_CARD_DEVICE
	if [ $? -ne 0 ]; then
		error "SD卡创建新分区失败"
		success=3
	fi

	# 格式化新分区为 FAT32
	info "格式化新分区为 FAT32..."
	for PARTITION in $(fdisk -l $SD_CARD_DEVICE | grep "^${SD_CARD_DEVICE}p[0-9]" | awk '{print $1}'); do
		mkdosfs -F 32 $PARTITION
		if [ $? -ne 0 ]; then
			error "SD卡分区 $PARTITION 格式化失败"
			success=4
		fi
	done
	return $success
}

# ACTION=remove
# $ACTION：add/remove
info "$SD_CARD_DEVICE: $ACTION"

# []中间需要空格
if [ "$ACTION" = "remove" ]; then
	# umount
	umount_sdcard
elif [ "$ACTION" = "add" ]; then
	check_sdcard
	result=$?
	if [ $result -eq 0 ]; then
		# sd卡符合要求，直接mount
		mount_sdcard
		result=$?
		if [ $result -ne 0 ]; then
			error "SD卡mount失败"
			return $result
		fi
	elif [ $result -ne 1 ]; then
		# 报错退出
		return $result
	else
		partition_and_format_sdcard
		result=$?
		if [ $result -ne 0 ]; then
			error "SD卡分区和格式化失败"
			return $result
		fi
		
		check_sdcard
		result=$?
		if [ $result -ne 0 ]; then
			error "SD卡分区和格式化失败"
			return $result
		else
			mount_sdcard
			result=$?
			if [ $result -ne 0 ]; then
				error "SD卡mount失败"
				return $result
			fi
		fi
	fi
	#info "加载模块，usb otg连接PC时可将sd卡挂载到PC"
	#modprobe g_mass_storage.ko file=/dev/mmcblk0 removable=1
	
	return 0
fi
