# S99custom.sh 切换说明 

本说明用于记录在 NFS 根文件系统下，`/etc/init.d/S99custom.sh` 的两个版本之间如何切换。

当前目录结构约定：

- `/etc/init.d/S99custom.sh`：**当前实际生效的启动脚本**
- `/etc/init.d/backup/S99custom.sh.orig`：原始版本（不开机自动启动 BMS）
- `/etc/init.d/backup/S99custom.sh.auto`：带 30 秒延时并自动启动 `/drivers/bms_20240403` 的版本  
- `/etc/init.d/backup/S99custom_switch.md`：本说明文档

> 所有命令都在开发机上执行，不是在板子上执行。

切换为「不开机自动启动 BMS」
使用原始版本脚本（不自启 BMS）：
cd /home/xixing/linux/nfs/buildroot/rootfs/etc/init.d
sudo cp backup/S99custom.sh.orig S99custom.sh
重启后，系统不会自动执行 /drivers/bms_20240403，需要手动运行。


切换为「30 秒延时自动启动 BMS」
使用带延时自启的脚本：
cd /home/xixing/linux/nfs/buildroot/rootfs/etc/init.d
sudo cp backup/S99custom.sh_2025-11-27_bms_auto S99custom.sh
重启后，系统按顺序执行各个 Sxx 脚本，在 S99custom.sh 中：

先做原有的 cron 权限和时间同步逻辑
打印日志：S99custom: 30 秒后自动启动 /drivers/bms_20240403
延时 30 秒
后台启动 /drivers/bms_20240403，日志输出到：
/root/log/bms_run.log
/root/log/bms_error.log


其他说明

/etc/init.d/backup/ 目录下的所有文件不会被 rcS/rcK 执行，只作为备份和文档使用。

真正参与系统启动的是 /etc/init.d/S99custom.sh，切换版本时只需要覆盖这一个文件。