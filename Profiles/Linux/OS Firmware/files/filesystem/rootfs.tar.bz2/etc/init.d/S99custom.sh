#!/bin/sh

# 函数：更新硬件时钟
update_hwclock() {
	# 脚本文件路径
	SCRIPT="/root/update_hwclock.sh"

	# Cron任务
	CRON_JOB="*/5 * * * * $SCRIPT"

	# 检查脚本文件是否存在
	if [ ! -f $SCRIPT ]; then
	    echo "脚本文件不存在: $SCRIPT"
	    return "$?"
	fi

	# 检查cron任务是否已经存在
	if crontab -l | grep -F "$SCRIPT" >/dev/null 2>&1; then
	    echo "Cron任务已存在: $CRON_JOB"
	    return "$?"
	fi

	# 添加新的cron任务
	(crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -

	echo "Cron任务已添加: $CRON_JOB"
}

# 函数：同步系统时钟
sync_date() {
        # 脚本文件路径
        SCRIPT="/root/sync_date.sh"

        # Cron任务
        CRON_JOB="*/1 * * * * $SCRIPT"

        # 检查脚本文件是否存在
        if [ ! -f $SCRIPT ]; then
            echo "脚本文件不存在: $SCRIPT"
            return "$?"
        fi

        # 检查cron任务是否已经存在
        if crontab -l | grep -F "$SCRIPT" >/dev/null 2>&1; then
            echo "Cron任务已存在: $CRON_JOB"
            return "$?"
        fi

        # 添加新的cron任务
        (crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -

        echo "Cron任务已添加: $CRON_JOB"
}

# 上电后根据/etc/timestamp初始化时钟
init_date() {
	# Set the system clock from hardware clock
	# If the timestamp is more recent than the current time,
	# use the timestamp instead.
	hwclock -s
	if test -e /etc/timestamp
	then
		SYSTEMDATE=`date -u +%4Y%2m%2d%2H%2M%2S`
		read TIMESTAMP < /etc/timestamp
		# if [ ${TIMESTAMP} -gt $SYSTEMDATE ]; then
			# format the timestamp as date expects it (2m2d2H2M4Y.2S)
			TS_YR=${TIMESTAMP:0:4}
		        TS_MON=${TIMESTAMP:4:2}
		        TS_DAY=${TIMESTAMP:6:2}
		        TS_HR=${TIMESTAMP:8:2}
		        TS_MIN=${TIMESTAMP:10:2}
		        TS_SEC=${TIMESTAMP:12:2}

			# Set system date using the timestamp
			logger -p local0.info "TS_YR: ${TS_MON}${TS_DAY}${TS_HR}${TS_MIN}${TS_YR}.${TS_SEC}"
			date -u ${TS_MON}${TS_DAY}${TS_HR}${TS_MIN}${TS_YR}.${TS_SEC}

			# Update hardware clock from system clock
			hwclock -w
		# fi
	fi
}

# 函数：添加数据库脚本的Cron任务
del_db_cron_job() {
    # 新的脚本文件路径
    DB_SCRIPT="/root/del_db_table.sh"

    # 新的Cron任务
    DB_CRON_JOB="0 1 * * * $DB_SCRIPT"

    # 检查新脚本文件是否存在
    if [ ! -f $DB_SCRIPT ]; then
        echo "脚本文件不存在: $DB_SCRIPT"
        return 1
    fi

    # 检查新的cron任务是否已经存在
    if crontab -l | grep -F "$DB_SCRIPT" >/dev/null 2>&1; then
        echo "Cron任务已存在: $DB_CRON_JOB"
        return 0
    fi

    # 添加新的cron任务
    (crontab -l 2>/dev/null; echo "$DB_CRON_JOB") | crontab -

    echo "Cron任务已添加: $DB_CRON_JOB"
}

start() {
	# 检查文件是否存在
	if [ ! -f /var/spool/cron/crontabs/root ]; then
	    echo "文件不存在: /var/spool/cron/crontabs/root"
	    exit 1
	fi

	# 修改文件的所属用户和所属组为root（保留原有逻辑）
	chown root:root /var/spool/cron/crontabs/root

	# 检查操作是否成功
	if [ $? -eq 0 ]; then
	    echo "文件的所属用户和所属组已成功修改为root。"
	else
	    echo "修改文件的所属用户和所属组时出错。"
	fi

	# init_date
	sync_date
	# update_hwclock
	# del_db_cron_job

	# 延时 30 秒后自动启动 BMS 应用
	if [ -x /drivers/bms_20240403 ]; then
	    echo "S99custom: 30 秒后自动启动 /drivers/bms_20240403"
	    sleep 30

	    mkdir -p /root/log
	    /drivers/bms_20240403 >> /root/log/bms_run.log 2>> /root/log/bms_error.log &
	else
	    echo "S99custom: 未找到可执行文件 /drivers/bms_20240403，跳过自动启动"
	fi
}

stop() {
	return 0
}

case "$1" in
	start|stop)
		"$1";;
	*)
		echo "Usage: $0 {start|stop}"
		exit 1
esac

